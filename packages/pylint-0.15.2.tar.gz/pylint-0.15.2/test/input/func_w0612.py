"""test unused variable
"""

__revision__ = 0

def function():
    """"yo"""
    aaaa = 1
